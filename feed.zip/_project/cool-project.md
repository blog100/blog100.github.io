---
layout: project_single
title:  "Cool Project"
slug: "cool-project"
---
Just a demo text for now, which signifies there is lot of scope for improvement.